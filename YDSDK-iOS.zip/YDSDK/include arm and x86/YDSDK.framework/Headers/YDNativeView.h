//
//  YDNativeAd.h
//  YDSDK
//
//  Created by Tychooo on 2017/4/11.
//  Copyright © 2017年 YodaMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YDNativeModel.h"

@protocol YDNativeDelegate;

@interface YDNativeView : UIView

@property (nonatomic, strong) YDNativeElementAdModel *nativeModel;
@property (nonatomic, weak) id<YDNativeDelegate> delegate;

- (instancetype)init;
- (instancetype)initWithFrame:(CGRect)frame;

@end
