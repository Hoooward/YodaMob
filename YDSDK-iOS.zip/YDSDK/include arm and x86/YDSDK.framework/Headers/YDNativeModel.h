//
//  YDNativeModel.h
//  YDSDK
//
//  Created by Tychooo on 2017/4/9.
//  Copyright © 2017年 YodaMob. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YDNativeElementAdModel : NSObject

/// Ad icon
@property (nonatomic, copy) NSString *icon;
/// Ad title
@property (nonatomic, copy) NSString *title;
/// Ad image
@property (nonatomic, copy) NSString *image;
/// Ad description
@property (nonatomic, copy) NSString *desc;
/// Ad button title
@property (nonatomic, copy) NSString *button;
/// Ad landing page url
@property (nonatomic, copy) NSString *choicesLinkUrl;
/// Ad logo image
@property (nonatomic, strong, nullable) UIImage *ADsignImage;
/// Ad star
@property (nonatomic, assign) float star;
/// Ad object code
@property (nonatomic, assign) NSInteger objCode;
/// Ad is from facebook or not
@property (nonatomic, assign) BOOL isFB;
/// Ad is from google or not
@property (nonatomic, assign) BOOL isAdMob;

@end

NS_ASSUME_NONNULL_END
