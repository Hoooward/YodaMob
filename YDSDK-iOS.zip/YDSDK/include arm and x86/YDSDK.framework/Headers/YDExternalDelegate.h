//
//  YDExternalDelegate.h
//  YDSDK
//
//  Created by Tychooo on 2017/3/30.
//  Copyright © 2017年 YodaMob. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "YDInterstitial.h"
//#import "YDBanner.h"
//#import "YDNativeTemplate.h"
//#import "YDNative.h"

@class YDInterstitial;
@class YDBanner;
@class YDNativeTemplate;
@class YDNative;

#pragma mark - Banner Delegate
@protocol YDBannerDelegate <NSObject>

@optional

/// User click the advertisement.
- (void)YDBannerDidClick:(YDBanner *)banner;

/// Advertisement landing page will show.
- (void)YDBannerDidIntoLandingPage:(YDBanner *)banner;

/// User left the advertisement landing page.
- (void)YDBannerDidLeaveLandingPage:(YDBanner *)banner;

/// User close the advertisement.
- (void)YDBannerClosed:(YDBanner *)banner;

/// Leave Application.
- (void)YDBannerWillLeaveApplication:(YDBanner *)banner;

/// User close the HTML5.
- (void)YDBannerHTML5Closed:(YDBanner *)banner;

@end

#pragma mark - Interstitial Delegate
@protocol YDInterstitialDelegate <NSObject>

@optional

/// User click the advertisement.
- (void)YDInterstitialDidClick:(YDInterstitial *)interstitialAd;

/// User close the advertisement.
- (void)YDInterstitialDidClosed:(YDInterstitial *)interstitialAd;

/// Advertisement landing page will show.
- (void)YDInterstitialDidIntoLandingPage:(YDInterstitial *)interstitialAd;

/// User left the advertisement landing page.
- (void)YDInterstitialDidLeaveLandingPage:(YDInterstitial *)interstitialAd;

/// Leave App.
- (void)YDInterstitialWillLeaveApplication:(YDInterstitial *)interstitialAd;

@end

#pragma mark - Native Template Delegate

@protocol YDNativeTemplateDelegate <NSObject>

@optional

/// User click the advertisement.
- (void)YDNativeTemplateDidClick:(YDNativeTemplate *)native;

/// Advertisement landing page will show.
- (void)YDNativeTemplateDidIntoLandingPage:(YDNativeTemplate *)native;

/// User left the advertisement landing page.
- (void)YDNativeTemplateDidLeaveLandingPage:(YDNativeTemplate *)native;

/// User close the advertisement.
- (void)YDNativeTemplateClosed:(YDNativeTemplate *)native;

/// Leave App.
- (void)YDNativeTemplateWillLeaveApplication:(YDNativeTemplate *)native;

/// User close the HTML5.
- (void)YDNativeTemplateHTML5Closed:(YDNativeTemplate *)native;

@end

#pragma mark - Native Delegate

@protocol YDNativeDelegate <NSObject>

@optional

/// User click the advertisement.
- (void)YDNativeAdDidClick:(UIView *)nativeAd;

/// Advertisement landing page will show.
- (void)YDNativeAdDidIntoLandingPage:(UIView *)nativeAd;

/// User left the advertisement landing page.
- (void)YDNativeAdDidLeaveLandingPage:(UIView *)nativeAd;

/// Leave App.
- (void)YDNativeAdWillLeaveApplication:(UIView *)nativeAd;

@end
