//
//  Copyright © 2017年 YodaMob. All rights reserved.
//  Created by Tychooo

#import <UIKit/UIKit.h>

@class YDNativeElementAdModel;

typedef NS_ENUM(NSUInteger, YDImageWidthHeightRate) {
    YDImageWHRateOneToOne = 0,
    YDImageWHRateOnePointNineToOne
};

@interface YDService : NSObject

///You should pass the singleton method to create the object, then calls the requests of the different types of ads.
+ (instancetype)shareManager;


/**
 Request Interstitial Ad View.

 @param slot_id : cloud teck intersitital Ad Id.
 @param delegate : set delegate of Ad event.
 @param isFull : if is screen, set YES, else set NO.
 @param keywords : aaaasss.
 @param isTest : use test advertisement or not.
 @param success : the request is successful block, return interstitial Ad view.
 @param failure : the request if failed block, return error.
 */
- (void)perloadInterstitialWithSlotId:(NSString *)slot_id
                             delegate:(id)delegate
                         isFullScreen:(BOOL)isFull
                             keywords:(NSString *)keywords
                               isTest:(BOOL)isTest
                              success:(void (^)(UIView *interstitialView))success
                              failure:(void (^)(NSError *error))failure;




/// Show interstitial advertisement.
/// Request success, then call this method show Ad view on current root view controller's view.
- (BOOL)interstitialShow;

/// Show interstitial advertisement.
/// Request success, the call this method show advertisement by present view controller style.
- (BOOL)interstitialShowWithViewController;



/**
 Request Banner Ad view.

 @param slot_id : cloud tech banner Ad Id.
 @param delegate : set delegate of Ad event.
 @param frame : set Ad view's frame.
 @param isNeedButton : show close button at the top-right corner of the advertisement.
 @param keywords : set Ad keywords or nil.
 @param isTest : use test advertisement or not.
 @param success : the request is successful block, return interstitial Ad view.
 @param failure : the request if failed block, return error.
 */
- (void)getBannerADswitchSlotId:(NSString *)slot_id
                       delegate:(id)delegate
                          frame:(CGRect)frame
                needCloseButton:(BOOL)isNeedButton
                       keywords:(NSString *)keywords
                         isTest:(BOOL)isTest
                        success:(void (^)(UIView * bannerView))success
                        failure:(void (^)(NSError *error))failure;


/**
 Requset Native Template Ad view.
 You can upload custom html5 template on our SSP website

 @param slot_id cloud tech NativeTemlate Ad Id
 @param delegate set delegate of Ad event.
 @param frame set Ad view's frame.
 @param isNeedButton : show close button at the top-right corner of the advertisement.
 @param keywords : set Ad keywords.
 @param isTest : use test advertisement or not.
 @param success : the request is successful block, return interstitial Ad view.
 @param failure : the request if failed block, return error.
 */
- (void)getNativeTemplateADswitchSlotId:(NSString *)slot_id
                           delegate:(id)delegate
                              frame:(CGRect)frame
                    needCloseButton:(BOOL)isNeedButton
                             isTest:(BOOL)isTest
                           keywords:(NSString *)keywords
                            success:(void (^)(UIView *naTemplateView))success
                            failure:(void (^)(NSError *error))failure;


/**
 Request Native Elements Ad

 @param slot_id cloud tech Native Ad Id
 @param delegate set delgate of Ad event
 @param WHRate set Image Rate
 @param keywords set Ad keywords
 @param isTest use test advertisement or not.
 @param success The request is successful Block, return Native Element Ad
 @param failure The request failed Block, retuen error
 */
- (void)getNativeElementsADswitchSlotId:(NSString *)slot_id
                       delegate:(id)delegate
            imageWidthHightRate: (YDImageWidthHeightRate)WHRate
                       keywords:(NSString *)keywords
                         isTest:(BOOL)isTest
                        success:(void (^)(YDNativeElementAdModel *))success
                        failure:(void (^)(NSError *))failure;



- (void)testGetTemplate;

@end
